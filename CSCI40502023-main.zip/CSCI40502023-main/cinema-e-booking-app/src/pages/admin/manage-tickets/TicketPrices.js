import React from "react"

export const TicketPrices = () => {
    return (
        <h1>Ticket Prices Page.</h1>
    )
}